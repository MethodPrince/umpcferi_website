<?php
/*
Template Name: About Page
*/
get_header(); ?>

<section class="about-page">
    <h1><?php the_title(); ?></h1>
    <?php
    if ( have_posts() ) {
        while ( have_posts() ) {
            the_post();
            the_content();
        }
    }
    ?>
</section>

<?php get_footer(); ?>
