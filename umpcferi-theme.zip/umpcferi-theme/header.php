<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header>
    <div class="site-branding">
        <h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
        <p><?php bloginfo( 'description' ); ?></p>
    </div>
    <nav>
        <?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'main-navigation' ) ); ?>
        <ul class="site-links">
            <li><a href="<?php echo esc_url( home_url( '/umpcferi-app' ) ); ?>">Site</a></li>
            <li><a href="<?php echo esc_url( home_url( '/login' ) ); ?>">Login</a></li>
        </ul>
    </nav>
</header>
<main>
