<?php
function umpcferi_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'umpcferi-theme' ),
    ) );
}
add_action( 'after_setup_theme', 'umpcferi_theme_setup' );

function umpcferi_theme_scripts() {
    wp_enqueue_style( 'umpcferi-theme-style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'umpcferi_theme_scripts' );

function umpcferi_breadcrumbs() {
    echo '<nav class="breadcrumbs"><a href="' . esc_url( home_url( '/' ) ) . '">Home</a></nav>';
}
